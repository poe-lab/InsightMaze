COMMUNICATION COMANDS
8BITS
SERIAL WIRING
megaTX1 -> nanoRX
nanoTX -> megaRX2


_ _ _ _ _ _ _ _
7 6 5 4 3 2 1 0

CONFIGURE DOORS
7 -> 0
6 -> 0
5 -> is door 5 open
4 -> is door 4 open
3 -> is door 3 open
2 -> is door 2 open
1 -> is door 1 open
0 -> is door 0 open



RUN SCT PROTOCOL
7 -> 0
6 -> 1
5 -> 0
4 -> 0
3 -> 0
2 -> 0
1 -> 0
0 -> 0

TIME STAMP
ID[8-bit]
Door triggered -> "001"


